package com.example.fingerprintauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class AdminActivity extends AppCompatActivity {

    // this group is for the group list (names) child list (approve or deny)
    // expandable list adapter is for the expandable list for the grouplist and childlist
    List<String> groupList;
    List<String> childList;
    Map<String, List<String>> employeeNames;
    ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;

    // loginName holds the name of the login user
    // loginID holds the name of the login user id
    String loginName = MainActivity.userString;
    String loginID = MainActivity.idString;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference tipList = db.collection("DailyIncomeFinal").document("2021-11-01").collection("Tip Data");

    // this is the name that shows up at the top of the screen
    // "Hello Name"
    TextView nameTxt;
    Spinner mySpinner;

    ImageButton refreshBtn;

    // array to store the names
    ArrayList<String> names = new ArrayList<>();
    static ArrayList<String> completeNames = new ArrayList<>();
    static ArrayList<String> fNameTips = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        expandableListView = findViewById(R.id.elvMobiles);
        refreshBtn = findViewById(R.id.refreshBtn);

        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, AdminActivity.class);
                startActivity(intent);
            }
        });

        // setting up GUI stuff
        nameTxt = findViewById(R.id.nameTxt);

        // Setting the "Hello, Name" txt
        nameTxt.setText("Hello, " + loginName);

        // static names for the groupList and creating them for the expandable list
        ReadData();

        // Spinner Start
        mySpinner = findViewById(R.id.spinner);
        ArrayAdapter<String> myAdapter = new ArrayAdapter(AdminActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.menu));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (parent.getItemAtPosition(position).equals("Distribution Modes")) {
                    Intent intent = new Intent(AdminActivity.this, DistributionModesActivity.class);
                    startActivity(intent);
                }

                else if (parent.getItemAtPosition(position).equals("Logout")) {
                    Intent intent = new Intent(AdminActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {


            }
        });
        // Spinner End
    }

    // DO NOT TOUCH THIS OR YOU WILL FEEL MY WRATH

    // Get the names programmatically
    public void ReadData() {
        // clearing the name and tips since we update tips and don't want the old ones
        completeNames.clear();
        fNameTips.clear();
        tipList.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    QuerySnapshot docs = task.getResult();
                    docs.getDocuments();
                    for( QueryDocumentSnapshot doc : docs) {
                        if (!(doc.getString("Role") == "FoHManager")) {
                            completeNames.add(doc.getString("name"));
                            fNameTips.add(String.format("%.2f", doc.getDouble("tips")));
                        }
                    }
                    // after reading and storing the names
                    // it will then be sent to the script that writes it to each expandable list
                    addToList(completeNames);
                }
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    // Creating the expandable list from here on down
    public void addToList(ArrayList<String> names) {
        createGroupList(names.toArray(new String[names.size()]));
        createCollection();
        // Creating the expandable list
        expandableListView = findViewById(R.id.elvMobiles);
        expandableListAdapter = new MyExpandableListAdapter(AdminActivity.this, groupList, employeeNames);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int lastExpandedPosition = -1;
            @Override
            public void onGroupExpand(int i) {
                if(lastExpandedPosition != -1 && i != lastExpandedPosition){
                    expandableListView.collapseGroup(lastExpandedPosition);
                }
                lastExpandedPosition = i;
            }
        });
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                return true;
            }
        });
    }

    // create the collection for the childLists per groupList
    private void createCollection() {
        String[] options = {"Approve", "Deny"};
        employeeNames = new HashMap<String, List<String>>();
        for(String group : groupList) {
            loadChild(options);
            employeeNames.put(group, childList);
        }
    }

    // Loading the child for the groupList
    private void loadChild(String[] options) {
        childList = new ArrayList<>();
        for(String option : options) {
            childList.add(option);
        }
    }

    // Creating the groupList
    private void createGroupList(String[] names) {
        groupList = new ArrayList<>();
        for(String name : names) {
            groupList.add(name);
        }
    }

    // onRestart for when we come back to this screen
    @Override
    protected void onRestart() {
        super.onRestart();
        setContentView(R.layout.activity_admin);

        // static names for the groupList and creating them for the expandable list
        ReadData();

        expandableListView = findViewById(R.id.elvMobiles);
        refreshBtn = findViewById(R.id.refreshBtn);

        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, AdminActivity.class);
                startActivity(intent);
            }
        });

        // setting up GUI stuff
        nameTxt = findViewById(R.id.nameTxt);

        // Setting the "Hello, Name" txt
        nameTxt.setText("Hello, " + loginName);

        // Spinner Start
        mySpinner = findViewById(R.id.spinner);
        ArrayAdapter<String> myAdapter = new ArrayAdapter(AdminActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.menu));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (parent.getItemAtPosition(position).equals("Distribution Modes")) {
                    Intent intent = new Intent(AdminActivity.this, DistributionModesActivity.class);
                    startActivity(intent);
                } else if (parent.getItemAtPosition(position).equals("Logout")) {
                    Intent intent = new Intent(AdminActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {


            }
        });
        // Spinner End
    }
}
