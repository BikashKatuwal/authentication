package com.example.fingerprintauth;


import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class DistributionCalculator {

    private ArrayList<String> Dates = new ArrayList<String>();          //array to hold dates (currently unused)
    private ArrayList<String> Names = new ArrayList<String>();          //array to hold first and last name
    private ArrayList<Double> Hours = new ArrayList<Double>();          //array for hours worked
    private ArrayList<TipRecord> DailyTipRecordList = new ArrayList<TipRecord>();  //array to hold list of daily record objects
    private static final DecimalFormat df = new DecimalFormat("0.00"); //create a format for currency
    private static float hourTotal;                                           //keeps a tally of total hours used for hourlySplit function
    private boolean namesRead = false;                                          //tracks if namesRead() function was run

    private FirebaseFirestore db = FirebaseFirestore.getInstance();  //get database instance
    CollectionReference dailyData = db.collection("data");

    public void hourlySplitDistribution(double tips) {                 //Divide income based on hours worked per employee
        float hourly = (float) (tips / hourTotal);                    //calculate the amount earned per hour for each hour worked in the day
        double dailyValue;                                          //variable to hold an individual's daily tip value
        for (int i = 0; i < DailyTipRecordList.size(); i++) {
            dailyValue = (DailyTipRecordList.get(i).getHours() * hourly);
            DailyTipRecordList.get(i).setTips(Double.parseDouble(df.format(dailyValue)));  //store that value in currency format in that individual's tip record object
        }
    }
    public void evenSplit(double tips) {                               //function to split tips equally for all workers who worked that day
        double splitAmount = (float)(tips/DailyTipRecordList.size());
        for(TipRecord employee: DailyTipRecordList) {
            employee.setTips(Double.parseDouble(df.format(splitAmount)));
        }
    }

    public void dailyValuesToDatabase () {
        if (!DailyTipRecordList.isEmpty()) {
            String docName = new String(DailyTipRecordList.get(0).getDate());       //set the document name to the Date of the tipRecords
            for (TipRecord record : DailyTipRecordList) {
                db.collection("DailyIncomeFinal").document(docName).collection("Tip Data").document(record.getName())
                        .set(record)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d("tipData", "Document Written!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("tipData", "Error", e);
                            }
                        });

            }
        }
        else if(DailyTipRecordList.isEmpty()) {
            Log.d("Empty", "empty");
        }
    }
    public boolean getNamesRead () {
        return namesRead;
    }

    public void getNames(String date) {
        dailyData.whereEqualTo("Date", date).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                int index = 0;
                TipRecord r_temp = new TipRecord();                 //placeholder TipRecord to add a daily employee record to the TipRecords arraylist
                hourTotal = 0;
                if (task.isSuccessful()) {
                    QuerySnapshot docs = task.getResult();
                    docs.getDocuments();
                    for (QueryDocumentSnapshot doc : docs) {
                        if (doc.getString("Role").equals("Weekly Total") || doc.getString("Role").equals("Report Total")) {
                            dailyData.document(doc.getId()).delete();
                            // Skipping
                        }
                        else {
                            Names.add(doc.getString("First") + " " + doc.getString("Last"));
                            Hours.add(Double.parseDouble(doc.getString("Regular hours")));

                            r_temp.setName(Names.get(index));                       // setting in array not in db
                            r_temp.setHours(Hours.get(index));
                            r_temp.setDate(doc.getString("Date"));
                            r_temp.setInTime(doc.getString("In Time"));
                            r_temp.setId(doc.getString("\uFEFFEmployee ID"));

                            //*************NEEDED FOR PREVENTING DUPLICATES***************
                            duplicate:  //define if branching to break out if duplicate found
                            if(DailyTipRecordList.size() == 0) {                //add first tip record to daily record list
                                hourTotal += Hours.get(index);                  //add to total daily hours
                                DailyTipRecordList.add(r_temp);
                            } else {
                                for (TipRecord record : DailyTipRecordList) {
                                    if (r_temp.getId().equals(record.getId()) && r_temp.getInTime().equals(record.getInTime())) { //if ID & name match ignore it as a duplicate
                                        break duplicate;
                                    } else if (r_temp.getId().equals(record.getId())) {         //if ID matches but In Times differ it is a double shift
                                        record.setHours(r_temp.getHours()+record.getHours());   //update hours to add the new shift
                                        record.setInTime(r_temp.getInTime());;                  //update in time to the new in time in case there is a duplicate of that value
                                        hourTotal += Hours.get(index);                          //update hours total
                                        break duplicate;
                                    }
                                }
                                DailyTipRecordList.add(r_temp);                         //if no duplicate in records add to daily list
                                hourTotal += Hours.get(index);                          //update hours total
                            }

                            ++index;
                            r_temp = new TipRecord();
                        }

                    }
                    namesRead = true;
                }
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    public void clearList(String date) {
        DailyTipRecordList.clear();
        namesRead = false;
        getNames(date);
    }
}
