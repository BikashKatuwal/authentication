//DistributionModesActivity  11/29

package com.example.fingerprintauth;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Date;

public class DistributionModesActivity extends AppCompatActivity {
    private Button button1;
    private Button button2;
    private Button button3;
    //private double tipValue;
    EditText totalTipTxt;

    EditText dateETxt;
    String dateTxt;

    Spinner mySpinner;

    AdminActivity aa = new AdminActivity();

    //FireBaseDatabase db = new FireBaseDatabase();
    DistributionCalculator dc = new DistributionCalculator();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distribution_modes);
        totalTipTxt = (EditText)findViewById(R.id.totalTipTxt);

        // defining the date
        dateETxt = findViewById(R.id.editTextDate);

        // Spinner Start
        mySpinner = findViewById(R.id.spinner3);
        ArrayAdapter<String> myAdapter = new ArrayAdapter(DistributionModesActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.menu3));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // back button goes  back to admin
                if (parent.getItemAtPosition(position).equals("Back")) {
                    Intent intent = new Intent(DistributionModesActivity.this, AdminActivity.class);
                    startActivity(intent);
                }
                // logout goes back to main
                else if (parent.getItemAtPosition(position).equals("Logout")) {
                    Intent intent = new Intent(DistributionModesActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        // Spinner End

        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dateTxt = dateETxt.getText().toString();
                if (dateTxt != null && !dateTxt.equals(dateETxt.getText().toString())) {
                    dateTxt = dateETxt.getText().toString();
                    dc.clearList(dateTxt);
                } else if (!dc.getNamesRead()){
                    dateTxt = dateETxt.getText().toString();
                    dc.getNames(dateTxt);
                }

                button1.setSelected(!button1.isSelected());
                String tipText = totalTipTxt.getText().toString();
                Double tipValue = Double.parseDouble(tipText);
                dc.hourlySplitDistribution(tipValue);
            }
        });

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dateTxt = dateETxt.getText().toString();
                if (dateTxt != null && !dateTxt.equals(dateETxt.getText().toString())) {
                    dateTxt = dateETxt.getText().toString();
                    dc.clearList(dateTxt);
                } else if (!dc.getNamesRead()){
                    dateTxt = dateETxt.getText().toString();
                    dc.getNames(dateTxt);
                }

                button2.setSelected(!button2.isSelected());
                String tipText = totalTipTxt.getText().toString();
                Double tipValue = Double.parseDouble(tipText);
                dc.evenSplit(tipValue);
            }
        });

        // makes sure that tips are written to db
        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setButtonView(button3);
                dc.dailyValuesToDatabase();
            }
        });
    }

    // changes the selected button so only 1 is selected at a time
    public void setButtonView(Button clickedButton) {
        if (clickedButton == button1) {
            button1.setSelected(!button1.isSelected());
            button2.setSelected(false);
            button3.setSelected(false);
        }
        else if (clickedButton == button2) {
            button1.setSelected(false);
            button2.setSelected(!button2.isSelected());
            button3.setSelected(false);
        }
        else if (clickedButton == button3) {
            button1.setSelected(false);
            button2.setSelected(false);
            button3.setSelected(!button3.isSelected());
        }
        else {
            button1.setSelected(false);
            button2.setSelected(false);
            button3.setSelected(false);
        }
    }
}
