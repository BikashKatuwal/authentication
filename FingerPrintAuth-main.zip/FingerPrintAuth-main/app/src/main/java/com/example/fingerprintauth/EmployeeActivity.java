package com.example.fingerprintauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class EmployeeActivity extends AppCompatActivity {

    // the spinner
    Spinner mySpinner;

    // the tipview for the name and tips
    TextView nameTxt;
    TextView tipAmountTxt;

    ImageButton refreshBtn;

    // loginName holds the name of the login user
    // loginID holds the name of the login user id
    String loginName = MainActivity.userString;
    String loginID = MainActivity.idString;
  
    // String that holds the calculated tip amount
    String tipCalculatedAmount;

    // connects to the firebase and a specific collection within the firestore
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference employeeList = db.collection("DailyIncomeFinal").document("2021-11-01").collection("Tip Data");

    // the 3 button options for recieving tips
    Button directDepositBtn;
    Button venmoBtn;
    Button cashBtn;

    @Override
    // Place to work on the Employee Screen
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);
      
        // finding the tips for the logged in user
        findTips(loginID);

        // defining and setting the name
        nameTxt = findViewById(R.id.nameTxt2);
        nameTxt.setText("Hello, " + loginName);

        refreshBtn = findViewById(R.id.refreshBtn2);

        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmployeeActivity.this, EmployeeActivity.class);
                startActivity(intent);
            }
        });
    }

    private void findTips(String id) {
        // finding the tips that are for the person with login ID used
        employeeList.whereEqualTo("id", id).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    QuerySnapshot docs = task.getResult();
                    docs.getDocuments();
                    for( QueryDocumentSnapshot doc : docs) {
                        tipCalculatedAmount = String.format("%.2f", doc.getDouble("tips"));
                    }
                }
              
                // setting the txts to the correct txt on the GUI
                nameTxt = findViewById(R.id.nameTxt2);
                tipAmountTxt = findViewById(R.id.tipAmountTxt);

                // Setting the name
                nameTxt.setText("Hello, " + loginName);

                // Spinner Start
                mySpinner = findViewById(R.id.spinner);
                ArrayAdapter<String> myAdapter = new ArrayAdapter(EmployeeActivity.this,
                        android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.menu2));
                myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mySpinner.setAdapter(myAdapter);

                mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                        // Options for the spinner. Only Logout can be clicked
                        if (parent.getItemAtPosition(position).equals("Logout")) {
                            Intent intent = new Intent(EmployeeActivity.this, MainActivity.class);
                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
                // Spinner End

                // setting up the buttons
                directDepositBtn = findViewById(R.id.ddBtn);
                venmoBtn = findViewById(R.id.venmoBtn);
                cashBtn = findViewById(R.id.cashBtn);

                // venmo and direct will be a future update
                directDepositBtn.setEnabled(false);
                venmoBtn.setEnabled(false);

                tipAmountTxt.setText("$" + tipCalculatedAmount);
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    // Resumes the program when coming back from another Activity
    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_employee);

        // Setting up the tips
        findTips(loginID);

        // Setting the name variable and defining it
        nameTxt = findViewById(R.id.nameTxt2);
        nameTxt.setText("Hello, " + loginName);

        refreshBtn = findViewById(R.id.refreshBtn2);

        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmployeeActivity.this, EmployeeActivity.class);
                startActivity(intent);
            }
        });
    }
}