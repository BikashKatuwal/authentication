package com.example.fingerprintauth;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import javax.net.ssl.KeyManagerFactorySpi;

public class FireBaseDatabase {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    // ArrayList<String> instead of String[]? -> future update (don't want to mess up the program rn)

    // Manager string arrays
    private String[] managerId = new String[100];
    private String[] managerLName = new String[100];
    private String[] managerFName = new String[100];
    private String[] managerFullName = new String[100];
    private String[] managerRole = new String[100];

    // Employee string arrays
    private String[] employeeId = new String[100];
    private String[] employeeLName = new String[100];
    private String[] employeeFName = new String[100];
    private String[] employeeFullName = new String[100];
    private String[] employeeRole = new String[100];

    // Arrays of both the employee's and managers
    private String[] allId = new String[100];
    private String[] allLName = new String[100];
    private String[] allFName = new String[100];
    private String[] allFullName = new String[100];
    private String[] allRole = new String[100];

    // answer is to send back to main activity login to determine who is logging in
    int answer;

    // full name of the one logging in
    public String loginFullName;

    // Reference to the db collection name
    CollectionReference employeeList = db.collection("data");

    public void getRoles() {
        // All Roles
        employeeList.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                int placeHolder = 0;
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();

                // the snapshot is 1 employee/manager
                for (DocumentSnapshot snapshot : snapshotList) {

                    // add each variable to the string array
                    allLName[placeHolder] = snapshot.getString("Last");
                    allId[placeHolder] = snapshot.get("\uFEFFEmployee ID").toString();
                    allFName[placeHolder] = snapshot.getString("First");
                    allRole[placeHolder] = snapshot.getString("Role");
                    allFullName[placeHolder] = allFName[placeHolder]
                            + " " + allLName[placeHolder];
                    ++placeHolder;
                }
            }
        });
        // Managers Roles
        employeeList.whereEqualTo("Role", "FoHManager").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                int placeHolder = 0;
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();

                // the snapshot is 1 employee/manager
                for (DocumentSnapshot snapshot : snapshotList) {

                    // add each variable to the string array
                    managerId[placeHolder] = snapshot.get("\uFEFFEmployee ID").toString();
                    managerLName[placeHolder] = snapshot.getString("Last");
                    managerFName[placeHolder] = snapshot.getString("First");
                    managerRole[placeHolder] = snapshot.getString("Role");
                    managerFullName[placeHolder] = managerFName[placeHolder]
                            + " " + managerLName[placeHolder];

                    ++placeHolder;
                }

            }
        });
        //Employee Roles
        employeeList.whereEqualTo("Role", "FoHUser").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                int placeHolder = 0;
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();
                // the snapshot is 1 employee/manager
                for (DocumentSnapshot snapshot : snapshotList) {

                    // add each variable to the string array
                    employeeLName[placeHolder] = snapshot.getString("Last");
                    employeeFName[placeHolder] = snapshot.getString("First");
                    employeeId[placeHolder] = snapshot.get("\uFEFFEmployee ID").toString();
                    employeeRole[placeHolder] = snapshot.getString("Role");
                    employeeFullName[placeHolder] = employeeFName[placeHolder]
                            + " " + employeeLName[placeHolder];

                    ++placeHolder;
                }
            }
        });
    }

    // function checks to see if this is a manager or an employee and returns the 'answer'
    // to determine who to login, if anyone at all
    public int checkManager(String uName, String pWord, int managerPlacement) {
        answer = 999;
        for(managerPlacement = 0; managerPlacement < allFName.length; managerPlacement++) {
            if (uName.equals(managerLName[managerPlacement]) && pWord.equals(managerId[managerPlacement])) {
                loginFullName = managerFullName[managerPlacement];
                answer = 0;
            }
            else if (uName.equals(employeeLName[managerPlacement]) && pWord.equals(employeeId[managerPlacement])) {
                answer = 1;
                loginFullName = employeeFullName[managerPlacement];
            }
        }
        return answer;
    }
}
