package com.example.fingerprintauth;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;

import java.sql.Connection;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {
    // Firebase Authentication System (have to check if in use)
    FirebaseAuth mAuth;

    // These two are the username and passwords that the employee enters
    EditText uNameTxt;
    EditText pWordTxt;

    // login is the fingerprint, authorize is the login button
    TextView msg_txt;
    ImageButton login_btn;
    Button authorize_btn;

    // the checkbox to link the u and p with biometric authentication
    CheckBox remember;

    // Strings hold the u and p that the user enters
    String uName;
    String pWord;

    // These string are used to compare to the 2 above strings for the remember box
    String newU;
    String newP;

    // string for the user that logged in
    String savedUser;

    // stores who logged in (last name and id)
    public static String userString;
    public static String idString;

    // Connects to FireBaseDatabase Script
    FireBaseDatabase db = new FireBaseDatabase();
    DistributionCalculator dc = new DistributionCalculator();

    // prompts for the fingerprint stuff
    BiometricPrompt biometricPrompt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setting the GUI stuff to their correlating objects
        uNameTxt = (EditText) findViewById(R.id.username_etxt);
        pWordTxt = (EditText) findViewById(R.id.password_etxt);
        msg_txt = findViewById(R.id.txt_msg);
        login_btn = findViewById(R.id.login_btn);
        authorize_btn = findViewById(R.id.authorize_btn);
        remember = findViewById(R.id.rememberMe);

        // preference and credentials are for the linkage
        SharedPreferences preferences = getSharedPreferences("credentials", MODE_PRIVATE);
        String credentials = preferences.getString("remember", "");

        SharedPreferences username = getSharedPreferences("username", MODE_PRIVATE);
        savedUser = username.getString("remember", "");

        //Following the Create a password-based account for firebase auth
        mAuth = FirebaseAuth.getInstance();

        // Gets the roles from the db
        db.getRoles();

        //BiometricManager to check if user can use fingerprint sensor
        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate()){
            case BiometricManager.BIOMETRIC_SUCCESS: //means we can use the biometric sensor
                msg_txt.setText("You can use the fingerprint sensor to login");
                msg_txt.setTextColor(Color.parseColor("#fafafa"));
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE: // this means that the device doesn't have the sensor
                msg_txt.setText("The device doesn't have a fingerprint sensor");
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE: // this means that its unavailable
                msg_txt.setText("The biometric sensors are currently unavailable");
                login_btn.setVisibility(View.GONE);
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED: // no fingerprint saved
                msg_txt.setText("Your device doesn't have any fingerprint saved, please check your security settings");
                login_btn.setVisibility(View.GONE);
                break;
        }

        //biometric dialog box
        //Executor
        Executor executor = ContextCompat.getMainExecutor(this);
        // prompt callback
        // result of authentication to see if we can login or not
        biometricPrompt = new BiometricPrompt(MainActivity.this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            // Error
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
            }

            @Override
            // Success
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                checkPreference(credentials);
            }

            @Override
            // Failure
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
            }
        });

        // checking the checkbox for if checked or not
        remember.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // checkbox is checked
                if(compoundButton.isChecked()) {
                    SharedPreferences preferences = getSharedPreferences("credentials", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    // if uName is empty, it shouldn't store the credentials
                    uName = getuName();
                    Log.d("Empty", "uName is: " + uName);
                    pWord = getpWord();
                    if (uName.equals("NULL")){
                        Toast.makeText(MainActivity.this, "Fill credentials", Toast.LENGTH_SHORT).show();
                    } else {
                        // Storing the credentials if uName isn't null or empty string
                        newU = uName;
                        newP = pWord;
                        editor.putString("remember", newU + " " + newP);
                        editor.apply();
                        Toast.makeText(MainActivity.this, "Checked", Toast.LENGTH_SHORT).show();
                    }
                    // Checkbox is not checked
                } else if (!compoundButton.isChecked()){
                    SharedPreferences preferences = getSharedPreferences("credentials", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("remember", "false");
                    editor.apply();
                    Toast.makeText(MainActivity.this, "Unchecked", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Biometric Dialog
        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Login")
                .setDescription("Use your fingerprint to login to your app")
                .setNegativeButtonText("Cancel")
                .build();



        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                biometricPrompt.authenticate(promptInfo);
            }
        });

        // Button will direct code to User Login
        authorize_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginUser();
            }
        });
    }

    // Getting the username string
    private String getuName() {
        uName = uNameTxt.getText().toString();
        if (uName != null || uName != "")
            return uName;
        else
            return "NULL";
    }

    // Getting the password String
    private String getpWord() {
        pWord = pWordTxt.getText().toString();
        if (pWord != null || pWord != "")
            return pWord;
        else
            return "NULL";
    }

    // Checking the preference
    // if null, they can't login with biometric
    // else the can
    private void checkPreference(String credentials) {
        String user = getuName();
        if (user.equals("NULL")){
            Toast.makeText(MainActivity.this, "Fill credentials", Toast.LENGTH_SHORT).show();
        } else {
            if(!credentials.equals("")){
                uNameTxt.setText(newU);
                pWordTxt.setText(newP);
            } else {
                Toast.makeText(getApplicationContext(), "No", Toast.LENGTH_SHORT).show();
            }
            LoginUser();
        }
    }

    // user login based on role
    // if it doesn't match anything, the credentials are wrong
    private void LoginUser(){
        uName = uNameTxt.getText().toString();
        pWord = pWordTxt.getText().toString();
        int i = 0;
        int result; // Manager(0) or Employee(1)
        result = db.checkManager(uName, pWord, i);

        // Holding username to know who logged in on next activity
        SharedPreferences username = getSharedPreferences("username", MODE_PRIVATE);
        SharedPreferences.Editor editor = username.edit();
        // if uName is empty, it shouldn't store the credentials
        Log.d("Empty", "uName is: " + uName);
        if (uName.equals("NULL")){
            Toast.makeText(MainActivity.this, "Fill credentials", Toast.LENGTH_SHORT).show();
        } else {
            // Storing the credentials if uName isn't null or empty string
            editor.putString("remember", uName);
            Log.d("LoginName", "uName that should be stored is: " + uName);
            editor.apply();
        }
        switch (result) {
            case 0:
                userString = uName;
                idString = pWord;
                openNewActivity(0);
                break;
            case 1:
                userString = uName;
                idString = pWord;
                openNewActivity(1);
                break;
            default:
                authorize_btn.setText("Wrong Credentials: Try Again");
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            reload();
        }
    }

    // depending on number from login from manager or employee
    // different activity will open
    public void openNewActivity(int i) {
        // more is Manager(0) or Employee(1)
        if(i == 0) {
            Intent intent = new Intent(this, AdminActivity.class);
            startActivity(intent);
        }
        if(i == 1) {
            Intent intent = new Intent(this, EmployeeActivity.class);
            startActivity(intent);
        }
    }

    // reload
    private void reload() { }
}