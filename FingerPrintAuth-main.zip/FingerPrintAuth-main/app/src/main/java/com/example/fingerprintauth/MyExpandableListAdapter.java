package com.example.fingerprintauth;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MyExpandableListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private Map<String, List<String>> employeeNames;
    private List<String> groupList;

    // the static names and tips from admin activity
    ArrayList<String> names = AdminActivity.completeNames;
    ArrayList<String> tips = AdminActivity.fNameTips;

    // array for the views on the expandable list (text, money, name)
    TextView[] arrayTextView= new TextView[2];
    TextView[] arrayNameView = new TextView[150];
    TextView[] arrayMoneyView = new TextView[150];
    View[] arrayView = new View[150];

    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference tipList = db.collection("DailyIncomeFinal").document("2021-11-01").collection("Tip Data");

    public MyExpandableListAdapter(Context context, List<String> groupList,
                                    Map<String, List<String>> employeeNames){
        this.context = context;
        this.employeeNames = employeeNames;
        this.groupList = groupList;
    }

    @Override
    public int getGroupCount() {
        return employeeNames.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return employeeNames.get(groupList.get(i)).size();
    }

    @Override
    public Object getGroup(int i) {
        return groupList.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        return employeeNames.get(groupList.get(i)).get(i1);
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    // gets the group view and sets the name and money amount
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        String employeeName = getGroup(i).toString();
        if(view == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.group_item, null);
        }

        // defining and setting the employee Name
        TextView item = view.findViewById(R.id.name);
        item.setTypeface(null, Typeface.BOLD);
        item.setText(employeeName);

        // defining each persons tips
        TextView money = view.findViewById(R.id.amount);
        money.setTypeface(null, Typeface.BOLD);

        // checks to see if the each person has a tip
        for (String name : names) {
            Log.d("Money", "employeeName: " + employeeName + " name: " + name);
            if (employeeName.equals(name)) {
                int position = names.indexOf(name);
                Log.d("Money", "tip: " + tips.get(position));
                money.setText(tips.get(position));
                Log.d("Money", money.toString());
                // if tip is 0, would like it all disabled
                /*if (money.getText().equals("0.00")) {
                    item.setEnabled(false);
                    money.setEnabled(false);
                }*/
            }
        }

        addParentView(view, item, money, i);

        return view;
    }

    @Override
    // gets the child view (approve and deny) and sets the text for the options
    public View getChildView(int i, int i1, boolean b, View view, ViewGroup viewGroup) {
        String option = getChild(i, i1).toString();
        if(view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.child_item, null);
        }
        TextView item = view.findViewById(R.id.option);
        item.setTextColor(Color.BLACK);
        item.setText(option);
        item.setEnabled(true);
        addTextView(item, i, i1);

        String employeeName = getGroup(i).toString();
        // disabling the views so that they cannot be clicked twice (one approve one deny)
        // would cause issues
        // if approve is clicked: tips = 0
        // if deny is clicked: tips != 0
        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(item.getText() == "Approve"){
                    Log.d("test", "Button clicked was: Approve");
                    for (String name : names) {
                        Log.d("Money", "employeeName: " + employeeName + " name: " + name);
                        if (employeeName.equals(name)) {
                            tipList.document(name).update("tips", 0).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Log.d("tipUpdate", "tip to 0 success");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d("tipUpdate", "tip to 0 fail");
                                }
                            });
                        }
                    }
                }
                else if(item.getText() == "Deny"){
                    Log.d("test", "Button clicked was: Deny");}

                disableParentView(i);
                disableTextView(i);

            }

        });

        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return false;
    }

    // adds the parentview
    private void addParentView (View parent, TextView name, TextView money, int i) { //Parent TextView
        arrayView[i] = parent;
        arrayNameView[i] = name;
        arrayMoneyView[i] = money;
    }

    // adds the textview
    private void addTextView (TextView textView, int i, int i1) { //Children TextView
        arrayTextView[i1] = textView;
    }

    // disables the parentView
    private void disableParentView (int i) {
            arrayNameView[i].setEnabled(false);
            arrayMoneyView[i].setEnabled(false);
            arrayView[i].setClickable(false);
    }

    // this disables the textview
    private void disableTextView (int i) {
        if(arrayNameView[i].isEnabled() == false) {
            for (int j = 0; j < getChildrenCount(i); j++) {
                arrayTextView[j].setEnabled(false);
                arrayTextView[j].setTextColor(Color.GRAY);
            }
        }
    }
}
