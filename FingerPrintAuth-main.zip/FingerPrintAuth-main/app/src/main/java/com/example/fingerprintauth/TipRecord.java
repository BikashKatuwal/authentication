package com.example.fingerprintauth;

import java.util.ArrayList;

public class TipRecord {
    private String name;
    private Double hours;
    private Double tips;
    private String Date;
    private String inTime;
    private String id;

    public TipRecord(String name, double hours, double tips, String date, String inTime, String id) {
        this.name = name;
        this.hours = hours;
        this.tips = tips;
        Date = date;
        this.inTime = inTime;
        this.id = id;
    }

    public TipRecord() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Double getTips() {
        return tips;
    }

    public void setTips(Double tips) {
        this.tips = tips;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInTime() {
        return inTime;
    }

    public void setInTime(String inTime) {
        this.inTime = inTime;
    }
}
